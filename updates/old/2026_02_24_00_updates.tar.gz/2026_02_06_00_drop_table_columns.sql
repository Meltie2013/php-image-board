-- Drop favorites and votes columns
ALTER TABLE `app_images` DROP `favorites`, DROP `votes`;
